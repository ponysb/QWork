import Vue from "vue";
const VueEvent = new Vue();
export default VueEvent;
