<template>
  <div>
    <Layout></Layout>
  </div>
</template>
<script>
import Layout from "./Layout";
export default {
  components: {
    Layout
  }
};
</script>
<style>
</style>